import React from 'react';
import { BarChart3, Brain, Database, GitBranch, Globe2, Mail, MessageSquare, Share2 } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-6 py-20">
          <div className="flex flex-col items-center text-center">
            <img
              src="https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200&h=200"
              alt="Profile"
              className="w-32 h-32 rounded-full border-4 border-white mb-6"
            />
            <h1 className="text-4xl font-bold mb-4">Sarah Anderson</h1>
            <p className="text-xl mb-6">Data Analyst & Insights Specialist</p>
            <div className="flex gap-4">
              <a href="#contact" className="bg-white text-blue-800 px-6 py-2 rounded-full font-semibold hover:bg-blue-50 transition-colors">
                Contact Me
              </a>
              <a href="#projects" className="border-2 border-white px-6 py-2 rounded-full font-semibold hover:bg-white/10 transition-colors">
                View Projects
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Skills Section */}
      <section className="py-20 bg-white" id="skills">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Core Competencies</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: <Database className="w-8 h-8" />, title: 'Data Analysis', desc: 'SQL, Python, R' },
              { icon: <BarChart3 className="w-8 h-8" />, title: 'Visualization', desc: 'Tableau, Power BI' },
              { icon: <Brain className="w-8 h-8" />, title: 'Machine Learning', desc: 'Predictive Analytics' },
              { icon: <Share2 className="w-8 h-8" />, title: 'Communication', desc: 'Data Storytelling' },
            ].map((skill, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg hover:shadow-lg transition-shadow">
                <div className="text-blue-600 mb-4">{skill.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{skill.title}</h3>
                <p className="text-gray-600">{skill.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20 bg-gray-50" id="projects">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: 'Sales Forecasting Model',
                desc: 'Developed predictive models achieving 94% accuracy in sales forecasting',
                image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800',
              },
              {
                title: 'Customer Segmentation',
                desc: 'Created customer segments using clustering algorithms for targeted marketing',
                image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800',
              },
              {
                title: 'Supply Chain Analytics',
                desc: 'Optimized inventory management reducing costs by 23%',
                image: 'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?auto=format&fit=crop&q=80&w=800',
              },
            ].map((project, index) => (
              <div key={index} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <img src={project.image} alt={project.title} className="w-full h-48 object-cover" />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-gray-600">{project.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white" id="contact">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Get in Touch</h2>
          <div className="max-w-2xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              {[
                { icon: <Mail className="w-6 h-6" />, title: 'Email', info: 'sarah@example.com' },
                { icon: <Globe2 className="w-6 h-6" />, title: 'Location', info: 'San Francisco, CA' },
                { icon: <MessageSquare className="w-6 h-6" />, title: 'LinkedIn', info: '@sarahanalyst' },
              ].map((contact, index) => (
                <div key={index} className="flex flex-col items-center text-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mb-4">{contact.icon}</div>
                  <h3 className="font-semibold mb-1">{contact.title}</h3>
                  <p className="text-gray-600">{contact.info}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-6 text-center">
          <div className="flex justify-center space-x-6 mb-4">
            <GitBranch className="w-6 h-6" />
          </div>
          <p className="text-gray-400">© 2024 Sarah Anderson. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;